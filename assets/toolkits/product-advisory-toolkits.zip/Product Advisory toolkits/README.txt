Product Advisory toolkits
=========================

Free templates and worksheets from Product Advisory. Use them, share them with your team, and adapt them to your work.

What's inside
-------------
1 Which prioritization method
  - which-prioritization-method.pdf: a one-page cheat sheet on when to use RICE, weighted scoring or ICE.

2 Build, Buy, or Partner
  - build-buy-partner-matrix.pdf: the printable decision matrix.
  - build-buy-partner-matrix.xlsx: the same matrix as a spreadsheet that does the math (Excel or Google Sheets).
  - build-buy-partner-worked-example.pdf: a filled-in example.

3 Organizational Impact Score
  - organizational-impact-score.pdf: the printable scorecard.
  - organizational-impact-score.xlsx: the spreadsheet version, with the scoring built in.
  - organizational-impact-score-worked-example.pdf: a filled-in example.

Interactive versions (free, in your browser)
--------------------------------------------
  Feature Prioritization Scorecard   https://www.productadvisory.co/scorecard
  AI Use Case Prioritization         https://www.productadvisory.co/ai-use-cases
  AI Readiness Checklist             https://www.productadvisory.co/ai-readiness
  Build, Buy, or Partner             https://www.productadvisory.co/build-buy-partner
  Organizational Impact Score        https://www.productadvisory.co/impact-score

Save your work and track your team's skills in Product Advisory Learning: https://assessment.productadvisory.co/
The latest version of this ZIP is always at https://www.productadvisory.co/toolkits

Questions, or want help with a decision? https://www.productadvisory.co/contact
