Product Advisory toolkits
=========================

Free templates and worksheets from Product Advisory. Use them, share them with your team, and adapt them to your work.

What's inside
-------------
Each spreadsheet has a Start Here tab, the scoring built in, and a worked example. They open in Excel or
Google Sheets (File, then Import).

1 Feature Prioritization Scorecard
  - feature-prioritization-scorecard.xlsx: rank features with weighted criteria or RICE, and compare the two.
  - which-prioritization-method.pdf: a one-page cheat sheet on when to use RICE, weighted scoring or ICE.

2 AI Use Case Prioritization
  - ai-use-case-prioritization.xlsx: score AI ideas on value, feasibility and risk, and find your first pilot.

3 AI Readiness Checklist
  - ai-readiness-checklist.xlsx: 24 statements, a score from 0 to 100, your stage, and what to fix first.

4 Build, Buy, or Partner
  - build-buy-partner-matrix.pdf: the printable decision matrix.
  - build-buy-partner-matrix.xlsx: the same matrix as a spreadsheet that does the math (Excel or Google Sheets).
  - build-buy-partner-worked-example.pdf: a filled-in example.

5 Organizational Impact Score
  - organizational-impact-score.pdf: the printable scorecard.
  - organizational-impact-score.xlsx: the spreadsheet version, with the scoring built in.
  - organizational-impact-score-worked-example.pdf: a filled-in example.

Interactive versions (free, in your browser)
--------------------------------------------
  Feature Prioritization Scorecard   https://www.productadvisory.co/scorecard
  AI Use Case Prioritization         https://www.productadvisory.co/ai-use-cases
  AI Readiness Checklist             https://www.productadvisory.co/ai-readiness
  Build, Buy, or Partner             https://www.productadvisory.co/build-buy-partner
  Organizational Impact Score        https://www.productadvisory.co/impact-score

Save your work and track your team's skills in Product Advisory Learning: https://assessment.productadvisory.co/
The latest version of this ZIP is always at https://www.productadvisory.co/toolkits

Questions, or want help with a decision? https://www.productadvisory.co/contact
